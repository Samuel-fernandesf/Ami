import MainLayout from "../layouts/MainLayout";

export default function UserProfilePage() {
  return (
    <MainLayout>
      <div>
        <h1>Perfil do Usuário</h1>
        <p>Conteúdo do perfil aqui.</p>
      </div>
    </MainLayout>
  );
}
