export default function UserProfile() {
    return (
        <section>
            <h2>User Profile</h2>
            <p>This is the user profile section.</p>
        </section>
    );
}